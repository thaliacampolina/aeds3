#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include "quicksort.h"
#include "estruturas.h"

int main(int argc, char* argv[]){

	char option,*input,*output,**strings,*nome;
	unsigned i,j,ncontatos,mbuffer,nblocos,ibloco,blocoAtual;

	Heap *heap,pop;

	float tempo_execucao;

	FILE *entrada;
	FILE *saida;
	FILE **bloco;

	struct timeval t_inicio;
	struct timeval t_fim;

	while((option = getopt(argc,argv,"i:o:")) != -1){

		switch(option){

			case 'i':
				input = optarg;
				break;

			case 'o':
				output = optarg;
				break;

			default :
				exit(0);
		}
	}
	//abre arquivo entrada
	entrada = fopen(input,"r");
	if(entrada == NULL)
		exit(0);

	saida = fopen(output,"w");
	if(saida == NULL)
		exit(0);	
	
	//lê numero de contatos n
	//lê tamanho m do buffer
	fscanf(entrada,"%u\n%u\n",&ncontatos,&mbuffer);

	//nblocos = teto(n/m)
	((ncontatos % mbuffer) != 0)? (nblocos = ((ncontatos/mbuffer) + 1)) : (nblocos = (ncontatos/mbuffer));

	//se ncontatos < mbuffer
	(ncontatos < mbuffer)? (mbuffer = ncontatos):(mbuffer = mbuffer);
		
	//aloca ponteiros pros blocos intermediários
	bloco = (FILE**)malloc(nblocos*sizeof(FILE*));
	if(bloco == NULL)
		exit(0);

	//aloca bloco de strings
	strings = (char**)malloc(mbuffer*sizeof(char*));
	if(strings == NULL)
		exit(0);

	//aloca o tamanho de cada string
	for(i = 0; i < mbuffer; i++){

		strings[i]= (char*)malloc(123*sizeof(char));
		if(strings[i] == NULL)
			exit(0);

	}

	//conta qtos caracteres serão necessário para o nome
	j = 12;
	i = 10; 
	while((nblocos/i) != 0){
		
		i *= 10;
		j++;
	}

	nome = (char*)malloc((j+1)*sizeof(char));
	if(nome == NULL)
		exit(0);

	/*--primeira-fase--*/
	
	//loop até fim do arquivo, n vezes
	//while(!feof(entrada)){

		for(i = 0; i < nblocos; i++){
			//lê bloco
			for(j = 0; j < mbuffer; j++){

				fgets(strings[j],123,entrada);
			}
			//ordena o bloco
			quicksort(strings,0,(mbuffer-1));
			//abre o arquivo intermediário
			sprintf(nome,"output_%u.txt",(i+1));
			bloco[i] =  fopen(nome,"w");
			if(bloco[i] == NULL)
				exit(0);

			//escreve o bloco ordenado na fita de saida, mfitas
			for(j = 0; j < mbuffer; j++){

				fprintf(bloco[i],"%s",strings[j]);
				strings[j][0]= '\0';
			}
			fclose(bloco[i]);
		}

	//}

	for(i = 0; i < mbuffer; i++){
		free(strings[i]);
	}

	free(strings);
	free(bloco);
	
	/*--fim-primeira-fase--*/
	/*--segunda-fase--*/

	//se o número de blocos é menor do que o buffer
	(nblocos < mbuffer)? (mbuffer = nblocos):(mbuffer = mbuffer);

	bloco  = (FILE**)malloc((mbuffer+1)*sizeof(FILE*));
	if(bloco == NULL)
		exit(0);

	heap = (Heap*)malloc(mbuffer*sizeof(Heap));
	if(heap == NULL)
		exit(0);

	for(i = 0; i < mbuffer; i++){

		heap[i].nome = (char*)malloc(123*sizeof(char));
		if(heap[i].nome == NULL)
			exit(0);
	}

	pop.nome = (char*)malloc(123*sizeof(char));
	if(pop.nome == NULL)
		exit(0);
	
	//carrega um registro de cada fita no heap
	for(i = 0; i < mbuffer; i++){

		sprintf(nome,"output_%u.txt",(i+1));
		bloco[i] =  fopen(nome,"r");
		if(bloco[i] == NULL)
			exit(0);
		//fscanf(bloco[i],"%[^\n]",heap[i].nome);
		fgets(heap[i].nome,123,bloco[i]);
		heap[i].origem = i;

	}
	j = i;
	constroiHeap(heap,mbuffer);

	blocoAtual = nblocos + 1;
	//loop até sobrar só uma fita	
	while(nblocos > mbuffer){		

		sprintf(nome,"output_%u.txt",blocoAtual);
		bloco[mbuffer] = fopen(nome,"w");
		if(bloco[mbuffer] == NULL)
			exit(0);
		
		while(heap[0].nome[1] != '\0'){

			//retira o menor
			retiraHeap(heap,&pop);

			//escreve na fita
			fprintf(bloco[mbuffer],"%s",pop.nome);

			fgets(pop.nome,123,bloco[pop.origem]);
			//se ainda há elemento no bloco
			if(!feof(bloco[pop.origem])){
				//coloca um novo elemento do heap, de mesma origem do retirado	
				//fscanf(bloco[pop.origem],"%[^\n]",pop.nome);				
				insereHeap(heap,pop);
			}
			//senao
			else{
				//acabou a fita
				heap[0].nome[0] = CHAR_MAX;
				heap[0].nome[1] = '\0';
			}
			refazHeap(1,mbuffer,heap);			
		}

		//se o heap esvaziou
		fclose(bloco[mbuffer]);
		blocoAtual++;
		nblocos = nblocos - mbuffer + 1; //m blocos intercalados se tornam 1

		//carrega um registro de cada bloco no heap
		for(i = 0; i < mbuffer; i++){
			
			sprintf(nome,"output_%u.txt",(i+j+1));
			fclose(bloco[i]);
			if(i < nblocos){

				bloco[i] = fopen(nome,"r");
				if(bloco[i] == NULL)
					exit(0);
				//fscanf(bloco[i],"%[^\n]",heap[i].nome);
				fgets(heap[i].nome,123,bloco[i]);
				heap[i].origem = i;
			}
			else{
				bloco[i] == NULL;
				heap[0].nome[0] = CHAR_MAX;
				heap[0].nome[1] = '\0';
				heap[i].origem = i;
			}
		}
		j = i + j;
		constroiHeap(heap,mbuffer);
			
	}
	//última intercalação, saída output.txt	
		
		while(heap[0].nome[1] != '\0'){

			//retira o menor
			retiraHeap(heap,&pop);

			//escreve na fita
			fprintf(saida,"%s",pop.nome);
			fgets(pop.nome,123,bloco[pop.origem]);

			//se ainda há elemento no bloco
			if(!feof(bloco[pop.origem])){
				//coloca um novo elemento do heap, de mesma origem do retirado
				insereHeap(heap,pop);
			}
			//senao
			else{
				//acabou a fita
				heap[0].nome[0] = CHAR_MAX;
				heap[0].nome[1] = '\0';
				fclose(bloco[pop.origem]);
			}
			refazHeap(1,mbuffer,heap);			
		}

		//se o heap esvaziou
		fclose(saida);

	/*--fim-segunda-fase--*/

	return 0;
}

/*
	gettimeofday(&t_inicio, NULL);
	gettimeofday(&t_fim, NULL);
	tempo_execucao = (t_fim.tv_sec-t_inicio.tv_sec)*1000000;
	tempo_execucao = (tempo_execucao+(t_fim.tv_usec-t_inicio.tv_usec))/1000000;
*/
