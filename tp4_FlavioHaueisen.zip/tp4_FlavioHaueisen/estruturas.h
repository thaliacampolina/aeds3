typedef struct{

	char* nome;
	unsigned origem;
}Heap;

/*-----funções do heap-----*/

void constroiHeap(Heap *heap ,unsigned n);
//constrói o heap O(nlogn)

void refazHeap(unsigned esq, unsigned dir, Heap *heap);
//refaz a ordem do heap O(logn)

void retiraHeap(Heap *heap, Heap *pop);
//retira o item do topo do heap O(1)

void insereHeap(Heap *heap , Heap item);
//insere o item no heap O(1)

/*---------*/



