#include <string.h>
#include "quicksort.h"

//quicksort wikipedia pt

void swap(char** vec, int a, int b) 
{
  char* tmp;
  tmp = vec[a];
  vec[a] = vec[b];
  vec[b] = tmp;
}
 
int partition(char** vec, int left, int right) 
{
  int i, j;
 
  i = left;
  for (j = left + 1; j <= right; ++j) 
  {
    if(strcmp(vec[j],vec[left]) < 0)
    {
      ++i;
      swap(vec,i,j);
    }
  }
  swap(vec,left,i);
 
  return i;
}
 
void quicksort(char** vec, int left, int right) 
{
  int r;
 
  if (right > left)
  {
    r = partition(vec, left, right);
    quicksort(vec, left, r - 1);
    quicksort(vec, r + 1, right);
  }
}


