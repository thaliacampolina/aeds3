//quicksort wikipedia pt
//http://pt.wikipedia.org/wiki/Quicksort

void swap(char** vec, int a, int b);

int partition(char** vec, int left, int right);

void quicksort(char** vec, int left, int right);


