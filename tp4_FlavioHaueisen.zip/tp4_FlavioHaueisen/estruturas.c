#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "estruturas.h"

/*-----funções do heap-----*/

void constroiHeap(Heap *heap ,unsigned n)
//constrói o heap O(nlogn)
{
	unsigned esq;

	esq = (n/2) + 1;

	while(esq > 1)
	{
		esq--;
		refazHeap(esq,n,heap);
	}
}
void refazHeap(unsigned esq, unsigned dir, Heap *heap)
//refaz a ordem do heap O(logu)
{
	unsigned i,j,xorigem;
	char xnome[122];
	
	i = esq;
	j = 2 * i;

	strcpy(xnome,heap[i-1].nome);
	xorigem = heap[i-1].origem;

	while(j <= dir)
	{
		if(j < dir)
		{
			if(strcmp(heap[j-1].nome,heap[j].nome) > 0)
				j++;
		}

		if((strcmp(xnome,heap[j-1].nome)) <= 0)
			break;

		strcpy(heap[i-1].nome,heap[j-1].nome);
		heap[i-1].origem = heap[j-1].origem;

		i = j;
		j = 2 * i;
	}
	
	strcpy(heap[i-1].nome,xnome);
	heap[i-1].origem = xorigem;
}
void retiraHeap(Heap *heap, Heap *pop)
//retira o item do topo do heap O(1)
{
	
	strcpy(pop->nome,heap[0].nome);
	pop->origem = heap[0].origem;

}

void insereHeap(Heap *heap , Heap item)
//insere o item no heap O(1)
{
	strcpy(heap[0].nome,item.nome);
	//não é necessário inserir a origem
	//pois ela deve ser a mesma do item que foi retirado
}
/*---------*/

